package TP_1;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;


public class XmlJsonConverter {
    
    private final XmlMapper xmlMapper;
    private final ObjectMapper jsonMapper;
    
    public XmlJsonConverter() {
        this.xmlMapper = new XmlMapper();
        this.jsonMapper = new ObjectMapper();
    }
    

    public String xmlToJsonWithAPI(String xml) throws Exception {
        JsonNode node = xmlMapper.readTree(xml.getBytes());
        return jsonMapper.writerWithDefaultPrettyPrinter().writeValueAsString(node);
    }
    
 
   
    public String jsonToXmlWithAPI(String json) throws Exception {
        JsonNode node = jsonMapper.readTree(json);
        return xmlMapper.writerWithDefaultPrettyPrinter().writeValueAsString(node);
    }
    

    
    String xmlToJsonManual(String xml) {
        try {
            xml = xml.trim();
            if (xml.isEmpty()) return "{}";
            
           
            if (xml.startsWith("<?xml")) {
                xml = xml.substring(xml.indexOf("?>") + 2).trim();
            }
            
            StringBuilder json = new StringBuilder("{\n");
            parseXmlToJson(xml, json, 1);
            json.append("\n}");
            
            return json.toString();
        } catch (Exception e) {
            return "{\n  \"error\": \"" + e.getMessage() + "\"\n}";
        }
    }
    
   
    private void parseXmlToJson(String xml, StringBuilder json, int level) {
        xml = xml.trim();
        if (xml.isEmpty()) return;
        
        String indent = "  ".repeat(level);
        
        int startTag = xml.indexOf('<');
        int endTag = xml.indexOf('>');
        
        if (startTag == -1 || endTag == -1) return;
        
        String tagName = xml.substring(startTag + 1, endTag).trim();
        if (tagName.startsWith("/")) return;
        
        String closeTag = "</" + tagName + ">";
        int closeIndex = xml.indexOf(closeTag);
        
        if (closeIndex == -1) return;
        
        String content = xml.substring(endTag + 1, closeIndex).trim();
        
        json.append(indent).append("\"").append(tagName).append("\": ");
        
 
        if (content.contains("<")) {
            json.append("{\n");
            parseXmlElements(content, json, level + 1);
            json.append("\n").append(indent).append("}");
        } else {
          
            if (content.matches("\\d+")) {
                json.append(content);
            } else {
                json.append("\"").append(content).append("\"");
            }
        }
    }
    
 
    private void parseXmlElements(String xml, StringBuilder json, int level) {
        xml = xml.trim();
        String indent = "  ".repeat(level);
        boolean first = true;
        
        while (xml.contains("<") && !xml.startsWith("</")) {
            int startTag = xml.indexOf('<');
            int endTag = xml.indexOf('>');
            
            if (startTag == -1 || endTag == -1) break;
            
            String tagName = xml.substring(startTag + 1, endTag).trim();
            if (tagName.startsWith("/")) break;
            
            String closeTag = "</" + tagName + ">";
            int closeIndex = xml.indexOf(closeTag);
            
            if (closeIndex == -1) break;
            
            if (!first) json.append(",\n");
            first = false;
            
            String content = xml.substring(endTag + 1, closeIndex).trim();
            
            json.append(indent).append("\"").append(tagName).append("\": ");
            
            if (content.matches("\\d+")) {
                json.append(content);
            } else {
                json.append("\"").append(content).append("\"");
            }
            
            xml = xml.substring(closeIndex + closeTag.length()).trim();
        }
    }
    
 
    public String jsonToXmlManual(String json) {
        try {
            json = json.trim();
            if (json.isEmpty()) return "<root/>";
            
            StringBuilder xml = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            
            json = json.substring(json.indexOf('{') + 1, json.lastIndexOf('}')).trim();
           
            String[] parts = json.split(":", 2);
            String rootTag = parts[0].trim().replaceAll("\"", "");
            
            xml.append("<").append(rootTag).append(">\n");
            
         
            if (parts.length > 1) {
                String content = parts[1].trim();
                if (content.startsWith("{")) {
                    content = content.substring(1, content.lastIndexOf('}')).trim();
                    parseJsonToXml(content, xml, 1);
                }
            }
            
            xml.append("</").append(rootTag).append(">");
            
            return xml.toString();
        } catch (Exception e) {
            return "<?xml version=\"1.0\"?>\n<error>" + e.getMessage() + "</error>";
        }
    }
    
   
    private void parseJsonToXml(String json, StringBuilder xml, int level) {
        String indent = "  ".repeat(level);
        String[] lines = json.split(",");
        
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty()) continue;
            
            if (line.contains(":")) {
                String[] parts = line.split(":", 2);
                String key = parts[0].trim().replaceAll("\"", "");
                String value = parts[1].trim().replaceAll("\"", "");
                
                xml.append(indent).append("<").append(key).append(">");
                xml.append(value);
                xml.append("</").append(key).append(">\n");
            }
        }
    }
}