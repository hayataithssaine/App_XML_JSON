package TP_1;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class XmlJsonConverterFX extends Application {

    private XmlJsonConverter converter;

    @Override
    public void start(Stage stage) {
       
        converter = new XmlJsonConverter();

        Label xmlLabel = new Label(" XML Input");
        xmlLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #e0e0e0;");
        
        Button clearXmlBtn = createClearButton();
        
        HBox xmlHeader = new HBox(10, xmlLabel, clearXmlBtn);
        xmlHeader.setAlignment(Pos.CENTER_LEFT);
        
        TextArea xmlArea = new TextArea();
        xmlArea.setPromptText("Entrer le XML ici...");
        xmlArea.setWrapText(true);
        xmlArea.setStyle("-fx-control-inner-background: #2b2b2b; -fx-text-fill: #e0e0e0; " +
                        "-fx-prompt-text-fill: #888888; -fx-font-size: 13px; -fx-font-family: 'Consolas', monospace;");
        
        clearXmlBtn.setOnAction(e -> xmlArea.clear());
        
        VBox xmlBox = new VBox(10, xmlHeader, xmlArea);
        VBox.setVgrow(xmlArea, Priority.ALWAYS);
        
        
        Label jsonLabel = new Label("JSON Output");
        jsonLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #e0e0e0;");
        
        Button clearJsonBtn = createClearButton();
        
        HBox jsonHeader = new HBox(10, jsonLabel, clearJsonBtn);
        jsonHeader.setAlignment(Pos.CENTER_LEFT);
        
        TextArea jsonArea = new TextArea();
        jsonArea.setPromptText("Resultat JSON...");
        jsonArea.setWrapText(true);
        jsonArea.setStyle("-fx-control-inner-background: #2b2b2b; -fx-text-fill: #e0e0e0; " +
                         "-fx-prompt-text-fill: #888888; -fx-font-size: 13px; -fx-font-family: 'Consolas', monospace;");
        
        clearJsonBtn.setOnAction(e -> jsonArea.clear());
        
        VBox jsonBox = new VBox(10, jsonHeader, jsonArea);
        VBox.setVgrow(jsonArea, Priority.ALWAYS);
        
      
        HBox textAreasContainer = new HBox(20, xmlBox, jsonBox);
        textAreasContainer.setPadding(new Insets(20));
        HBox.setHgrow(xmlBox, Priority.ALWAYS);
        HBox.setHgrow(jsonBox, Priority.ALWAYS);
        
    
        Label apiLabel = new Label(" Avec API Jackson");
        apiLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #64B5F6; -fx-font-weight: bold;");
        
        Button xmlToJsonApiBtn = createButton("XML → JSON", "#2196F3");
        Button jsonToXmlApiBtn = createButton("JSON → XML", "#2196F3");
        
        xmlToJsonApiBtn.setOnAction(e -> convertWithAPI(xmlArea, jsonArea, true));
        jsonToXmlApiBtn.setOnAction(e -> convertWithAPI(jsonArea, xmlArea, false));
        
        VBox apiButtonsBox = new VBox(8, apiLabel, new HBox(15, xmlToJsonApiBtn, jsonToXmlApiBtn));
        apiButtonsBox.setAlignment(Pos.CENTER);
        
     
        Label manualLabel = new Label("Conversion Manuelle");
        manualLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #FFB74D; -fx-font-weight: bold;");
        
        Button xmlToJsonManualBtn = createButton("XML → JSON", "#FF9800");
        Button jsonToXmlManualBtn = createButton("JSON → XML", "#FF9800");
        
        xmlToJsonManualBtn.setOnAction(e -> convertManually(xmlArea, jsonArea, true));
        jsonToXmlManualBtn.setOnAction(e -> convertManually(jsonArea, xmlArea, false));
        
        VBox manualButtonsBox = new VBox(8, manualLabel, new HBox(15, xmlToJsonManualBtn, jsonToXmlManualBtn));
        manualButtonsBox.setAlignment(Pos.CENTER);
        
        HBox allButtonsBox = new HBox(40, apiButtonsBox, manualButtonsBox);
        allButtonsBox.setAlignment(Pos.CENTER);
        allButtonsBox.setPadding(new Insets(15, 20, 20, 20));
        
        BorderPane root = new BorderPane();
        root.setCenter(textAreasContainer);
        root.setBottom(allButtonsBox);
        root.setStyle("-fx-background-color: #1e1e1e;");
        
        Scene scene = new Scene(root, 700, 420);
        stage.setScene(scene);
        stage.setTitle("Conversion XML ⇄ JSON");
        stage.show();
    }
    
   
    private Button createClearButton() {
        Button btn = new Button("Clear");
        btn.setStyle("-fx-font-size: 11px; -fx-background-color: #f44336; -fx-text-fill: white; " +
                    "-fx-background-radius: 3; -fx-cursor: hand; -fx-padding: 5 10 5 10;");
        btn.setOnMouseEntered(e -> btn.setStyle("-fx-font-size: 11px; -fx-background-color: #d32f2f; " +
                                                "-fx-text-fill: white; -fx-background-radius: 3; -fx-cursor: hand; -fx-padding: 5 10 5 10;"));
        btn.setOnMouseExited(e -> btn.setStyle("-fx-font-size: 11px; -fx-background-color: #f44336; " +
                                               "-fx-text-fill: white; -fx-background-radius: 3; -fx-cursor: hand; -fx-padding: 5 10 5 10;"));
        return btn;
    }
    
    
    private Button createButton(String text, String color) {
        Button btn = new Button(text);
        String baseStyle = "-fx-font-size: 13px; -fx-background-color: " + color + "; -fx-text-fill: white; " +
                          "-fx-background-radius: 5; -fx-cursor: hand; -fx-padding: 8 15 8 15;";
        
        btn.setPrefWidth(160);
        btn.setPrefHeight(40);
        btn.setStyle(baseStyle);
        
        String hoverColor = color.equals("#2196F3") ? "#1976D2" : "#F57C00";
        
        btn.setOnMouseEntered(e -> btn.setStyle(baseStyle + "-fx-background-color: " + hoverColor + ";"));
        btn.setOnMouseExited(e -> btn.setStyle(baseStyle));
        
        return btn;
    }

   
    private void convertWithAPI(TextArea inputArea, TextArea outputArea, boolean isXmlToJson) {
        Task<String> task = new Task<>() {
            @Override
            protected String call() throws Exception {
                String input = inputArea.getText();
                if (isXmlToJson) {
                    return converter.xmlToJsonWithAPI(input);
                } else {
                    return converter.jsonToXmlWithAPI(input);
                }
            }
            
            @Override
            protected void succeeded() {
                outputArea.setText(getValue());
            }
            
            @Override
            protected void failed() {
                Platform.runLater(() -> 
                    outputArea.setText("Erreur: " + getException().getMessage())
                );
            }
        };
        new Thread(task).start();
    }

  
    private void convertManually(TextArea inputArea, TextArea outputArea, boolean isXmlToJson) {
        Task<String> task = new Task<>() {
            @Override
            protected String call() throws Exception {
                String input = inputArea.getText();
                if (isXmlToJson) {
                    return converter.xmlToJsonManual(input);
                } else {
                    return converter.jsonToXmlManual(input);
                }
            }
            
            @Override
            protected void succeeded() {
                outputArea.setText(getValue());
            }
            
            @Override
            protected void failed() {
                Platform.runLater(() -> 
                    outputArea.setText("Erreur: " + getException().getMessage())
                );
            }
        };
        new Thread(task).start();
    }

    public static void main(String[] args) {
        launch(args);
    }
}